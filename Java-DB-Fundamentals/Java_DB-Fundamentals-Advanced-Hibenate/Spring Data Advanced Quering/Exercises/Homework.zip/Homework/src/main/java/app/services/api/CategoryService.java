package app.services.api;

import app.entities.Category;

import java.util.List;

public interface CategoryService {

}
