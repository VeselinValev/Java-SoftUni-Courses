package app.enums;

public enum EditionType {
    NORMAL, PROMO, GOLD
}
