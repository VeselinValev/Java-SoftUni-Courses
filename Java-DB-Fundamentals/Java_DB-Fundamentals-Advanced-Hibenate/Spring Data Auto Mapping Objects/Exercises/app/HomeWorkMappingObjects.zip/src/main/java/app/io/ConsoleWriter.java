package app.io;

public interface ConsoleWriter {
    void writeLine(String text);
}
