package app.io;

import java.io.IOException;

public interface ConsoleReader {
    String readLine() throws IOException;
}
