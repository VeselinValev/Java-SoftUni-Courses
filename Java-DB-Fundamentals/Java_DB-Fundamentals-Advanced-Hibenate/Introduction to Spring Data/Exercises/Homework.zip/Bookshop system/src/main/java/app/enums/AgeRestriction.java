package app.enums;

public enum AgeRestriction {
    MINOR, TEEN, ADULT
}
