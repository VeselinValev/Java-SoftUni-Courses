package core.commands;

public class FightCommand extends Command {

    @Override
    public String execute() {
        return "fight";
    }
}
