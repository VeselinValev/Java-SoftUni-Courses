package contracts;

public interface Attacker {
    
    int getAttackDamage();
}
