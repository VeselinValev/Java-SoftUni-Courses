package contracts;

public interface Executable {

	String execute();

}
