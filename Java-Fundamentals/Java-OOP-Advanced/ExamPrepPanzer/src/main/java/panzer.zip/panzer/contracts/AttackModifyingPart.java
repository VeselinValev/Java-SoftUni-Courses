package panzer.contracts;

public interface AttackModifyingPart extends Part {
    int getAttackModifier();
}
