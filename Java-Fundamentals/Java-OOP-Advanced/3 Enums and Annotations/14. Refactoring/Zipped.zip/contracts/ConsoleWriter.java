package contracts;

public interface ConsoleWriter {
    void writeLine(String line);
}
