package contracts;

import java.io.IOException;

public interface ConsoleReader {
    String readLine() throws IOException;
}
