package contracts;

public interface Gem {
    int getStrength();

    int getAgility();

    int getVitality();
}
