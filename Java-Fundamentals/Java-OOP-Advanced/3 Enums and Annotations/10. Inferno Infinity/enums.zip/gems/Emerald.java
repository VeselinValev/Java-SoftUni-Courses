package gems;

public class Emerald extends Gem{
    public Emerald(int strength, int agility, int vitality) {
        super(strength, agility, vitality);
    }
}
