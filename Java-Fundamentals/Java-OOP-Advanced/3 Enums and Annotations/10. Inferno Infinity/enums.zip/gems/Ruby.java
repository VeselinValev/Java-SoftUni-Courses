package gems;

public class Ruby extends Gem{
    public Ruby(int strength, int agility, int vitality) {
        super(strength, agility, vitality);
    }
}
