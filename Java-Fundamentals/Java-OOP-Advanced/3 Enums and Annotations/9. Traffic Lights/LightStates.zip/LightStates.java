public enum LightStates {
    RED, GREEN, YELLOW
}
