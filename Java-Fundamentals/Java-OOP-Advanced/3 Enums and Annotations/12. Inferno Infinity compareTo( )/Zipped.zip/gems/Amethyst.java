package gems;

public class Amethyst extends Gem{
    public Amethyst(int strength, int agility, int vitality) {
        super(strength, agility, vitality);
    }
}
