package inventoryTests;

import hell.entities.miscellaneous.HeroInventory;
import hell.interfaces.Inventory;
import hell.interfaces.Item;
import hell.interfaces.Recipe;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class InventoryTests {
    private Inventory heroInventory;
    private Item item1;
    private Item item2;
    private Recipe recipe;

    @Before
    public void before(){
        this.heroInventory = new HeroInventory();
        this.item1 = Mockito.mock(Item.class);
        this.item2 = Mockito.mock(Item.class);
        this.recipe = Mockito.mock(Recipe.class);

        List<String> requiredItems = List.of("item1", "item2");
        Mockito.when(this.recipe.getName()).thenReturn("name");
        Mockito.when(this.recipe.getStrengthBonus()).thenReturn(1_000_000_000);
        Mockito.when(this.recipe.getAgilityBonus()).thenReturn(1_000_000_000);
        Mockito.when(this.recipe.getIntelligenceBonus()).thenReturn(1_000_000_000);
        Mockito.when(this.recipe.getHitPointsBonus()).thenReturn(1_000_000_000);
        Mockito.when(this.recipe.getDamageBonus()).thenReturn(1_000_000_000);
        Mockito.when(this.recipe.getRequiredItems()).thenReturn(requiredItems);


        Mockito.when(this.item1.getAgilityBonus()).thenReturn(2_000_000_000);
        Mockito.when(this.item1.getStrengthBonus()).thenReturn(2_000_000_000);
        Mockito.when(this.item1.getIntelligenceBonus()).thenReturn(2_000_000_000);
        Mockito.when(this.item1.getDamageBonus()).thenReturn(2_000_000_000);
        Mockito.when(this.item1.getHitPointsBonus()).thenReturn(2_000_000_000);
        Mockito.when(this.item1.getName()).thenReturn("item1");

        Mockito.when(this.item2.getAgilityBonus()).thenReturn(2_000_000_000);
        Mockito.when(this.item2.getStrengthBonus()).thenReturn(2_000_000_000);
        Mockito.when(this.item2.getIntelligenceBonus()).thenReturn(2_000_000_000);
        Mockito.when(this.item2.getDamageBonus()).thenReturn(2_000_000_000);
        Mockito.when(this.item2.getHitPointsBonus()).thenReturn(2_000_000_000);
        Mockito.when(this.item2.getName()).thenReturn("item2");
    }

    @Test
    public void ifGettersReturnsLong(){
        this.heroInventory.addCommonItem(this.item1);
        this.heroInventory.addCommonItem(this.item2);
        Assert.assertEquals(4_000_000_000L, this.heroInventory.getTotalAgilityBonus());
        Assert.assertEquals(4_000_000_000L, this.heroInventory.getTotalStrengthBonus());
        Assert.assertEquals(4_000_000_000L, this.heroInventory.getTotalDamageBonus());
        Assert.assertEquals(4_000_000_000L, this.heroInventory.getTotalHitPointsBonus());
        Assert.assertEquals(4_000_000_000L, this.heroInventory.getTotalIntelligenceBonus());
    }
    

    @Test
    public void checkAddCommonItemMethod() throws NoSuchFieldException, IllegalAccessException {
        this.heroInventory.addCommonItem(this.item1);
        this.heroInventory.addCommonItem(this.item2);
        Field commonItemCount = this.heroInventory.getClass().getDeclaredField("commonItems");
        commonItemCount.setAccessible(true);
        int actualCommonItemsLength = ((Map<String, Item>) commonItemCount.get(this.heroInventory)).size();
        Assert.assertEquals(2, actualCommonItemsLength);
    }

    @Test
    public void checkAddRecipeItemMethod() throws NoSuchFieldException, IllegalAccessException {
        this.heroInventory.addRecipeItem(this.recipe);
        Field recipeItemCount = this.heroInventory.getClass().getDeclaredField("recipeItems");
        recipeItemCount.setAccessible(true);
        int actualRecipeItemsLength = ((Map<String, Recipe>) recipeItemCount.get(this.heroInventory)).size();
        Assert.assertEquals(1, actualRecipeItemsLength);
    }
}
