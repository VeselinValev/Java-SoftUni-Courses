package hell.constants;

public class Messages {
    public static final String HERO_CREATED = "Created %s - %s";
    public static final String ITEM_CREATED = "Added item - %s to Hero - %s";
    public static final String RECIPE_CREATED = "Added recipe - %s to Hero - %s";
}
