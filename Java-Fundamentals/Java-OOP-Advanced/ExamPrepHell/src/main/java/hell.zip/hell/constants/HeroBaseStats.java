package hell.constants;

public class HeroBaseStats {
    public static final int[] BARBARIAN = {90, 25, 10, 350, 150};
    public static final int[] ASSASSIN = {25, 100, 15, 150, 300};
    public static final int[] WIZARD = {25, 25, 100, 100, 250};
}
