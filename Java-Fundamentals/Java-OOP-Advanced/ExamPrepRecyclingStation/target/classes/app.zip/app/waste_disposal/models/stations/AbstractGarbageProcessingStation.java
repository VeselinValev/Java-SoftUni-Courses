package app.waste_disposal.models.stations;

import app.waste_disposal.contracts.GarbageProcessingStation;
import app.waste_disposal.contracts.ProcessingData;

public abstract class AbstractGarbageProcessingStation implements GarbageProcessingStation {
    private double energy;
    private double capital;


    AbstractGarbageProcessingStation() {
        this.energy = 0;
        this.capital = 0;
    }

    @Override
    public double getEnergy() {
        return this.energy;
    }

    @Override
    public double getCapital() {
        return this.capital;
    }

    @Override
    public void addProcessingData(ProcessingData data){
        this.energy += data.getEnergyBalance();
        this.capital += data.getCapitalBalance();
    }
}
