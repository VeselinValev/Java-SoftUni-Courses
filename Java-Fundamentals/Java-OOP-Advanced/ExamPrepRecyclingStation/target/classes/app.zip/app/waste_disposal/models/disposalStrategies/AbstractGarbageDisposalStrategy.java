package app.waste_disposal.models.disposalStrategies;

import app.waste_disposal.contracts.GarbageDisposalStrategy;

public abstract class AbstractGarbageDisposalStrategy implements GarbageDisposalStrategy {
    AbstractGarbageDisposalStrategy() {
    }
}
