package app.waste_disposal.factories;

import app.waste_disposal.contracts.Waste;
import app.waste_disposal.models.garbage.BurnableGarbage;
import app.waste_disposal.models.garbage.RecyclableGarbage;
import app.waste_disposal.models.garbage.StorableGarbage;

public class WasteFactory {
    public static Waste createWaste(String name, double volumePerKg, double weight, String type){
        Waste waste;
        if (type.equals("Recyclable")){
            waste = new RecyclableGarbage(name, volumePerKg, weight);
        }else if (type.equals("Burnable")){
            waste = new BurnableGarbage(name, volumePerKg, weight);
        }else{
            waste = new StorableGarbage(name, volumePerKg, weight);
        }
        return waste;
    }
}
