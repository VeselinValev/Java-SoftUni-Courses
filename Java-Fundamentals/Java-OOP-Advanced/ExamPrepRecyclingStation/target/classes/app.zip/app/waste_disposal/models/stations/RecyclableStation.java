package app.waste_disposal.models.stations;

public class RecyclableStation extends AbstractGarbageProcessingStation {

}
