package app.waste_disposal.contracts;

public interface GarbageProcessingStation {
    double getEnergy();

    double getCapital();

    void addProcessingData(ProcessingData data);
}
