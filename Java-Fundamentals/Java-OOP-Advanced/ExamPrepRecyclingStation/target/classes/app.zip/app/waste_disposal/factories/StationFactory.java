package app.waste_disposal.factories;

import app.waste_disposal.contracts.GarbageProcessingStation;
import app.waste_disposal.models.stations.BurnableStation;
import app.waste_disposal.models.stations.RecyclableStation;
import app.waste_disposal.models.stations.StoreableStation;

public class StationFactory {
    public static GarbageProcessingStation createRecyclableStation() {

        return new RecyclableStation();
    }

    public static GarbageProcessingStation createBurnableStation() {

        return new BurnableStation();
    }

    public static GarbageProcessingStation createStoreableStation() {

        return new StoreableStation();
    }

}
