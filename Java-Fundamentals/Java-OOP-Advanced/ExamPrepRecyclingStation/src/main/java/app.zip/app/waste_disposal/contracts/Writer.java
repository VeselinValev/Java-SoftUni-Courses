package app.waste_disposal.contracts;

public interface Writer {

    void writeLine(String output);
}
